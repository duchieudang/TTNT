import pandas as pd
import numpy as np
dt = pd.read_csv("E:/1/Book1.csv")
p = np.array([dt['Cao'],dt['Rong'],dt['Chin']])
t= np.array([dt['Loai']])
p=p.T
t=t.T
test = np.array([[8,7,8]])
w=np.array([[-1,-1,1]])
b=0
a=0
k=0
m=len(p)
while True:
    d=True
    k+=1
    print("Lan lap thu",k)
    for i in range(m):
      x= np.array([p[i]])
      n=w.dot(x.T) + b
      if n<0:
       a=-1
      else:
       a=1
      if(a!=t[i]):
       e=t[i]-a
       w=w+np.dot(e,x)
       b=b+e
       d=False
    print("w",w)
    print("b",b)
    if d==True:
       break

n= w.dot(test.T) + b
if n<0:
  wr="San pham dat yeu cau"
else:
  wr = "San pham khong dat yeu cau"
print("San pham test:\"" + wr +"\"")
