import numpy as np
p=np.array([[8,9,9],[4,4,6],[9,8,8],[5,6,4]])
test=np.array([[8,7,8]])
t=[1,-1,1,-1]
w=np.array([[20,1,3]])
b= 5
a=0
k=0
while True:
	d=True
	k+=1
	print("lan lap thu ",k)

	for i in range(4):
		x=np.array([p[i]])
		n=w.dot(x.T)+b
		if n<0:
			a=-1
		else :
			a=1
		if(np.array_equal(t[i],a)==False):
			e=t[i]-a
			w=w+np.dot(e,x)
			b=b+e
			d=False
	print("w=",w)
	print("b=",b)
	if(d==True):
		break
n=w.dot(test.T)+b
if n<0:
	wr="-1"
else :
	wr="1"
print("Voi x1=3,x2=9,x3=4=>thuoc lop "+"\""+wr+"\"")
print("n",n)